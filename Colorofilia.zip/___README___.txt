PROJET DE MELVIN ET AMBRE
Developpement: Melvin
design et graphisme: Ambre







PROJET NESSECITANT: 
	python 3.7:
Sous W10
https://www.python.org/downloads/windows/

Sous mac:
https://www.python.org/downloads/mac-osx/

Sous autre plateForme
https://www.python.org/download/other/



tkinter (graphisme)
Normalement inclu de base



pygame (audio)
Sous window
 py -3.7 -m pip install pygame


================================

LANCER LE PROGRAMME:

executer Interface.py


================================
Synopsis:

les couleurs on disparue, découvrez se qu'il c'est passé !

Commande:

Tout se joue au clique, 

ATTENTION ! marteller le clique met en file d'attente les evenement (et peu donc skip un dialogue par ex) 

